
package data_P;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class LoadHC_2_1 {

	static int[] HC;

	ArrayList<ArrayList<Integer>> allhc = new ArrayList<ArrayList<Integer>>();

	static ArrayList<ArrayList<Integer>> all = new ArrayList<ArrayList<Integer>>();
	
	public static void loadHC(File file) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(file));
			List<Integer> list = new ArrayList<Integer>();
			String contentLine = br.readLine();
			while(contentLine != null){
				int value = Integer.parseInt(contentLine);
				list.add(value);
				contentLine = br.readLine();
			}
			HC = new int[list.size()];
			for(int i = 0; i < list.size(); i++){
				HC[i] = list.get(i);
			}
			br.close();
	    }

	public void loadAll(String path) throws Exception{
		File[] files_hc = new File(path).listFiles();
		for(int i = 0; i < files_hc.length; i++){
			LoadHC_2_1.loadHC(files_hc[i]);
			ArrayList<Integer> temp = new ArrayList<>();
			for(int j = 0; j < HC.length; j++){
				temp.add(HC[j]);
			}
			allhc.add(temp);
		}
	}
	

	public void combination(){
		System.out.println(allhc.size());
		for(int i = 0; i < allhc.size()-1; i++){
			for(int j = i+1; j < allhc.size(); j++){
				ArrayList<Integer> temp = new ArrayList<>();
				temp.addAll(allhc.get(i));
				temp.addAll(allhc.get(j));
				all.add(temp);
			}
		}
	}
	

	public void isTrue(){
		for(int i = 0; i < allhc.size(); i++){
			String temp = allhc.get(i).toString();
			System.out.println(temp);
		}
		System.out.println("----------------------------------------------");
		
		for(int i = 0; i < all.size(); i++){
			String temp = all.get(i).toString();
			System.out.println(temp);
		}
	}
}
