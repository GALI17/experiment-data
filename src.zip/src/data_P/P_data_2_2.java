//����֤��ȷ��
package data_P;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class P_data_2_2 {
	
	public int[][] pp ;

	public void loadPhenotype(String name) throws Exception{
		BufferedReader br = null;
			List<int[]> vecList = new ArrayList<int[]>();
			FileReader fr = new FileReader(name);
			br = new BufferedReader(fr);

			String contentLine = br.readLine();
			while(contentLine != null){
				String[] items = contentLine.split(" ");

				int[] rowData = new int[items.length+1]; 
				for(int j = 0; j < items.length; j++){
					rowData[j] = Integer.parseInt(items[j]);
				}
				vecList.add(rowData);
				contentLine = br.readLine();
			}
			pp = new int[vecList.size()][];
			for(int i = 0; i < vecList.size(); i++){
				pp[i] = vecList.get(i);
			}
			br.close();
		}
	


	public void ptag() throws IOException{
		System.out.println(LoadHC_2_1.all.size());
		for(int k = 0; k < LoadHC_2_1.all.size(); k++){
			
			int[][] ppp = newpp(pp);
			
			for(int i = 0; i < LoadHC_2_1.all.get(k).size(); i++){
				int temp = LoadHC_2_1.all.get(k).get(i);
				for(int j = 0; j < ppp.length; j++){
					if(j == temp-1){
						ppp[j][ppp[0].length-1] = 1;
					}
				}
			}
			writeNewP(ppp,"E:\\PSOlab\\30-26\\inp\\inp" +Test_2.q+"\\inp" + (k+1) + ".txt");
		}
	}
	private int[][] newpp(int[][] pp) {
		int r = pp.length;
		int c = pp[0].length;
		int[][] ppp = new int[r][c];
		
		for(int i = 0; i < r; i++){
			for(int j = 0; j < c; j++){
				ppp[i][j] = 0;
			}
		}
		
		for(int i = 0; i < r; i++){
			for(int j = 0; j < c; j++){
				ppp[i][j] = pp[i][j];
			}
		}
		
		return ppp;
	}
	private void writeNewP(int[][] ppp, String string) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(string));

		for(int i = 0; i < ppp.length; i++){
			for(int j = 0; j < ppp[0].length; j++){
				bw.write(String.valueOf(ppp[i][j]) + " ");
				}
			bw.newLine();
			}
		bw.close();
	}
	
}
