
package data_P;

import java.util.ArrayList;


public class Test_2 {
	static int q;
	public static void main(String[] args) throws Exception{

		String str = "E:\\PSOlab\\30-26\\";
		
		for(q = 1; q <= 100; q++){
			LoadHC_2_1 lhc = new LoadHC_2_1();
			lhc.loadAll(str + "hc\\hc"+q);
			lhc.combination();
			//lhc.isTrue();
			
			
			P_data_2_2 p22 = new P_data_2_2();
			p22.loadPhenotype(str + "p\\p"+q);
			p22.ptag();

			LoadHC_2_1.all = new ArrayList<ArrayList<Integer>>();
		}

	}

}
