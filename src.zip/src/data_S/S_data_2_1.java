
package data_S;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class S_data_2_1 {
	
	public int[][] ss ;

	public void loadS(String name) throws Exception{
		BufferedReader br = null;
			List<int[]> vecList = new ArrayList<int[]>();
			FileReader fr = new FileReader(name);
			br = new BufferedReader(fr);

			String contentLine = br.readLine();
			while(contentLine != null){
				String[] items = contentLine.split(" ");

				int[] rowData = new int[items.length+1];
				for(int j = 0; j < items.length; j++){
					rowData[j] = Integer.parseInt(items[j]);
				}
				vecList.add(rowData);
				contentLine = br.readLine();
			}
			ss = new int[vecList.size()][];
			for(int i = 0; i < vecList.size(); i++){
				ss[i] = vecList.get(i);
			}
			br.close();
		}
	


	public void ptag() throws IOException{
		for(int k = 0; k < LoadHC_1_2.all.size(); k++){
			
			int[][] sss = newss(ss);
			
			for(int i = 0; i < LoadHC_1_2.all.get(k).size(); i++){
				int temp = LoadHC_1_2.all.get(k).get(i);
				for(int j = 0; j < sss.length; j++){
					if(j == temp-1){
						sss[j][sss[0].length-1] = 1;
					}
				}
			}
			writeNewS(sss,"E:\\PSOlab\\30-26\\ins\\ins" + S_Test_2.r +"\\ins" + (k+1) + ".txt");
		}
	}
	private int[][] newss(int[][] ss) {
		int r = ss.length;
		int c = ss[0].length;
		int[][] sss = new int[r][c];
		
		for(int i = 0; i < r; i++){
			for(int j = 0; j < c; j++){
				sss[i][j] = 0;
			}
		}
		
		for(int i = 0; i < r; i++){
			for(int j = 0; j < c; j++){
				sss[i][j] = ss[i][j];
			}
		}
		
		return sss;
	}
	private void writeNewS(int[][] sss, String string) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(string));

		for(int i = 0; i < sss.length; i++){
			for(int j = 0; j < sss[0].length; j++){
				bw.write(String.valueOf(sss[i][j]) + " ");
				}
			bw.newLine();
			}
		bw.close();
	}
	
}
