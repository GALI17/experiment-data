package data_S;

import java.util.ArrayList;

public class S_Test_2 {
	static int r;
	public static void main(String[] args) throws Exception{
		String str = "E:\\PSOlab\\30-26\\";

		for(r=1; r<=100; r++){
			LoadHC_1_2 lhc = new LoadHC_1_2();
			lhc.loadAll(str + "hc\\hc"+r);
			lhc.combination();
			//lhc.isTrue();
					
			S_data_2_1 s3 = new S_data_2_1();
			s3.loadS(str + "s\\s"+r);
			s3.ptag();
			
			LoadHC_1_2.allhc = new ArrayList<ArrayList<Integer>>();
			LoadHC_1_2.all = new ArrayList<ArrayList<Integer>>();
		}
	}
}
